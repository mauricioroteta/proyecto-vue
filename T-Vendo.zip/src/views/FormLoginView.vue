<template>
  <div>
    <FormLogin />
  </div>
</template>

<script>

// @ is an alias to /src
import FormLogin from '@/components/FormLogin.vue';

export default {
  name: 'FormLoginView',
  components: {
    FormLogin
  }
}
</script>
