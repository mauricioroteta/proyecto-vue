<template>
  <div>
    <Compras />
  </div>
</template>

<script>

// @ is an alias to /src
import Compras from '@/components/Compras.vue';

export default {
  name: 'ComprasView',
  components: {
    Compras
  }
}
</script>
