<template>
    <div>
      <UsrAlta />
    </div>
  </template>
  
  <script>
  
  // @ is an alias to /src
  import UsrAlta from '@/components/UsrAlta.vue';
  
  export default {
    name: 'UsrAltaView',
    components: {
        UsrAlta
    }
  }
  </script>
  